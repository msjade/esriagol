# AGOL Secure Overlay + Attributes Proxy — Client Package

Included:
- portal_maplibre.html  -> ready-to-run viewer (overlay + click identify + query + CSV export)
- client_snippets.md    -> integration snippets for MapLibre/Mapbox, OpenLayers, ArcGIS JS, Leaflet notes
- AGOL_Secure_Overlay_Proxy_Documentation.pdf -> admin + client documentation

Run the portal locally (recommended):
1) Put portal_maplibre.html in a folder
2) Start a local web server:
   python -m http.server 9000
3) Open:
   http://localhost:9000/portal_maplibre.html

In the portal:
- Proxy Base URL: your Render domain
- Dataset alias: ipa_ea_frame_v1 / ipa_bld_sample_v1
- Client Key: CK_... (the key you issued)
