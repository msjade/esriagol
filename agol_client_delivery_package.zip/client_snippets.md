# Client Integration Snippets (Overlay + Attribute Query)

## Vector Tile Overlay (recommended)
Style URL:
  https://<PROXY>/tiles/<ALIAS>/style.json?key=<CLIENT_KEY>

Example:
  https://esriagol.onrender.com/tiles/ipa_ea_frame_v1/style.json?key=CLIENTKEY_DEMO_123

## Identify (click attributes only)
GET:
  https://<PROXY>/v1/<ALIAS>/identify?lat=<LAT>&lon=<LON>&key=<CLIENT_KEY>

## Query (attributes only)
GET:
  https://<PROXY>/v1/<ALIAS>/query?where=<SQL>&outFields=<CSV_FIELDS>&resultRecordCount=200&key=<CLIENT_KEY>

Example:
  https://esriagol.onrender.com/v1/ipa_ea_frame_v1/query?where=STATE_NAME%3D%27BAUCHI%27&outFields=STATE_NAME,LGA_NAME,EA_ID&resultRecordCount=50&key=CLIENTKEY_DEMO_123

## OpenLayers (Mapbox Style)
Use `ol-mapbox-style`:

```html
<script src="https://cdn.jsdelivr.net/npm/ol@latest/dist/ol.js"></script>
<script src="https://unpkg.com/ol-mapbox-style@11.5.0/dist/olms.js"></script>
<div id="map" style="width:100%;height:100vh"></div>
<script>
  const styleUrl = "https://esriagol.onrender.com/tiles/ipa_ea_frame_v1/style.json?key=CLIENTKEY_DEMO_123";
  olms('map', styleUrl).then(map => {
    map.getView().setCenter(ol.proj.fromLonLat([8.67, 9.08]));
    map.getView().setZoom(6);
  });
</script>
```

## ArcGIS JS (VectorTileLayer)
```js
require(["esri/Map","esri/views/MapView","esri/layers/VectorTileLayer"], function(Map, MapView, VectorTileLayer){
  const vt = new VectorTileLayer({
    style: "https://esriagol.onrender.com/tiles/ipa_ea_frame_v1/style.json?key=CLIENTKEY_DEMO_123"
  });
  const map = new Map({ basemap: "gray-vector", layers: [vt] });
  new MapView({ container: "viewDiv", map, center: [8.67, 9.08], zoom: 6 });
});
```

## Leaflet
Leaflet needs a vector-tile plugin. Simplest: use MapLibre (or the provided portal HTML).
