# React Native Integration

Use a MapLibre-compatible library (preferred) or a WebView map.

## Style URL
EA frame:
https://YOUR_PROXY_BASE/tiles/ea_frame/style.json?key=CK_YOUR_KEY

Buildings:
https://YOUR_PROXY_BASE/tiles/buildings/style.json?key=CK_YOUR_KEY

## Identify on press (fetch)
```js
const PROXY = "https://YOUR_PROXY_BASE";
const KEY   = "CK_YOUR_KEY";
const alias = "ea_frame"; // or buildings

async function identify(lat, lon){
  const url = `${PROXY}/v1/${alias}/identify?lat=${lat}&lon=${lon}&max_results=3&key=${encodeURIComponent(KEY)}`;
  const res = await fetch(url);
  return await res.json();
}
```

## Notes
- Keys in mobile apps can be extracted. Ask for a restricted key if needed.
