AGOL Secure Proxy — Client Delivery Package (Modified)

What’s inside
1) AGOL_Secure_Proxy_Client_Integration_Pack.pdf
   - Full integration guide (Windows + Android/iOS/Flutter/React Native)
   - Endpoints + allowed fields for ea_frame and buildings

2) samples/
   - windows/maplibre/index.html  (recommended)
   - windows/openlayers/index.html (raw MVT fallback)
   - mobile/* README snippets
   - api/postman_collection.json + curl_examples.txt

3) service_catalog.json
   - Machine-readable summary of services and allowed fields.

Quick start
A) Replace placeholders in the sample files:
   - https://YOUR_PROXY_BASE  -> your provided proxy base URL
   - CK_YOUR_KEY             -> your provided client key

B) Windows quick test
   - Open: samples/windows/maplibre/index.html in Chrome/Edge
   - Click on overlay to run Identify and view attributes.

C) API quick test (curl)
   - Use: samples/api/curl_examples.txt

Troubleshooting
- 401: missing/invalid/disabled key
- 403: key valid but not allowed for alias
- 404: alias not registered
