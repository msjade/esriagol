# AGOL Secure Proxy - Client Samples (Windows + Mobile)

These samples show how to:
1) Display secure overlays (vector tiles) using the proxy style endpoint
2) Call Identify/Query endpoints for approved attributes

You must replace:
- YOUR_PROXY_BASE
- CK_YOUR_KEY

Aliases used in this pack:
- ea_frame
- buildings

---

## Windows (Web) - MapLibre GL JS
Open:
- windows/maplibre/index.html

---

## Windows (Web) - OpenLayers (MVT direct)
Open:
- windows/openlayers/index.html

Note: OpenLayers does not consume Mapbox style.json directly. It uses raw MVT PBF tiles with a simple style.

---

## Android / iOS (MapLibre Native)
See:
- mobile/android/README.md
- mobile/ios/README.md

---

## Flutter
See:
- mobile/flutter/README.md

---

## React Native
See:
- mobile/react-native/README.md

---

## API quick tests (curl)
See:
- api/curl_examples.txt

---

## Postman Collection
Import:
- api/postman_collection.json
