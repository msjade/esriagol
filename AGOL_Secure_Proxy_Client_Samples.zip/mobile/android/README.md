# Android (MapLibre Native) Integration

## 1) Load overlay style
Use the proxy style endpoint:

EA frame:
https://YOUR_PROXY_BASE/tiles/ea_frame/style.json?key=CK_YOUR_KEY

Buildings:
https://YOUR_PROXY_BASE/tiles/buildings/style.json?key=CK_YOUR_KEY

## 2) Identify on tap
Call:
https://YOUR_PROXY_BASE/v1/{alias}/identify?lat={lat}&lon={lon}&max_results=3&key=CK_YOUR_KEY

## Kotlin (concept)
```kotlin
val proxy = "https://YOUR_PROXY_BASE"
val key   = "CK_YOUR_KEY"
val alias = "ea_frame" // or buildings

val styleUrl = "$proxy/tiles/$alias/style.json?key=$key"
mapView.getMapboxMap().loadStyleUri(styleUrl)

// On tap:
val identifyUrl = "$proxy/v1/$alias/identify?lat=$lat&lon=$lon&max_results=3&key=$key"
// Use OkHttp/Retrofit to fetch JSON and show attributes in a bottom sheet / popup.
```

## Notes
- Store the key securely if possible, but assume mobile keys can be extracted.
- If you need per-state access control, request a key with a server-side where restriction.
