# Flutter Integration

Your Flutter app needs:
1) a MapLibre/Mapbox-style map widget that can load a style URL
2) http calls for identify/query

## Style URL
EA frame:
https://YOUR_PROXY_BASE/tiles/ea_frame/style.json?key=CK_YOUR_KEY

Buildings:
https://YOUR_PROXY_BASE/tiles/buildings/style.json?key=CK_YOUR_KEY

## Identify on tap
https://YOUR_PROXY_BASE/v1/{alias}/identify?lat={lat}&lon={lon}&max_results=3&key=CK_YOUR_KEY

## Dart snippet (HTTP)
```dart
import 'dart:convert';
import 'package:http/http.dart' as http;

Future<Map<String, dynamic>> identify({
  required String proxy,
  required String key,
  required String alias,
  required double lat,
  required double lon,
}) async {
  final uri = Uri.parse('$proxy/v1/$alias/identify?lat=$lat&lon=$lon&max_results=3&key=$key');
  final res = await http.get(uri);
  return jsonDecode(res.body) as Map<String, dynamic>;
}
```

## Notes
- Plugin choices vary by team (maplibre_gl, mapbox_gl, etc.)
- If the plugin cannot load Mapbox styles, use a WebView map or request a raster tile alternative.
