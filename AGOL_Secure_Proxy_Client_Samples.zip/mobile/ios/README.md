# iOS (MapLibre Native) Integration

## 1) Load overlay style
EA frame:
https://YOUR_PROXY_BASE/tiles/ea_frame/style.json?key=CK_YOUR_KEY

Buildings:
https://YOUR_PROXY_BASE/tiles/buildings/style.json?key=CK_YOUR_KEY

## 2) Identify on tap
https://YOUR_PROXY_BASE/v1/{alias}/identify?lat={lat}&lon={lon}&max_results=3&key=CK_YOUR_KEY

## Swift (concept)
```swift
let proxy = "https://YOUR_PROXY_BASE"
let key   = "CK_YOUR_KEY"
let alias = "ea_frame" // or buildings

let styleUrl = URL(string: "\(proxy)/tiles/\(alias)/style.json?key=\(key)")!
// mapView.mapboxMap.loadStyleURI(.init(url: styleUrl)!)

func identify(lat: Double, lon: Double) async throws -> Data {
  let url = URL(string: "\(proxy)/v1/\(alias)/identify?lat=\(lat)&lon=\(lon)&max_results=3&key=\(key)")!
  let (data, _) = try await URLSession.shared.data(from: url)
  return data
}
```
